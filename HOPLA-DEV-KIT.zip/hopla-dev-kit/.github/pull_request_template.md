## Objectif

## Modifications réalisées

## Captures avant/après (si UI)

## Vérifications effectuées
- [ ] Lint
- [ ] Typecheck
- [ ] Build
- [ ] Tests pertinents
- [ ] Vérification responsive
- [ ] Vérification accessibilité / SEO / sécurité

## Risques et régressions possibles

## Procédure de retour arrière
